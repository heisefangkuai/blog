# Privilege Escalation by Buffer Overflow (Vulnhub)

This is a List of CTF Challenges in which privilege Escalation would be done by Buffer Overflow. Clicking on the Lab Name, will redirect you to the writeup of that particular lab on [hackingarticles](https://www.hackingarticles.in). We have performed and compiled this list on our experience. Please share this with your connections and direct queries and feedback to [Pavandeep Singh](https://www.linkedin.com/in/pavan2318).

[1.1]: http://i.imgur.com/tXSoThF.png
[1]: http://www.twitter.com/rajchandel
# Follow us on [![alt text][1.1]][1]

| No | Machine Name                                                                                            |
|----|---------------------------------------------------------------------------------------------------------|
|1.	 |[Tr0ll 2](https://www.hackingarticles.in/hack-the-tr0ll-2-boot2root-challenge/)|
|2.	 |[IMF](https://www.hackingarticles.in/hack-imf-vm-ctf-challenge/)|
|3.	 |[BSides London 2017](https://www.hackingarticles.in/hack-the-bsides-london-vm-2017boot2root/)|
|4.	 |[PinkyPalace](https://www.hackingarticles.in/hack-the-pinkypalace-vm-ctf-challenge/)|
|5.	 |[ROP Primer](https://www.hackingarticles.in/hack-the-rop-primer-1-0-1-ctf-challenge/)|
|6.  |[CTF KFIOFAN:2](https://www.hackingarticles.in/ctf-kfiofan-2-vulnhub-walkthorugh/)|
|7.  |[Kioptrix : Level 1](https://www.hackingarticles.in/hack-the-kioptrix-level-1/)|
|8.  |[Silky-CTF: 0x02](https://www.hackingarticles.in/silky-ctf-0x02-vulhub-walkthrough/)|
