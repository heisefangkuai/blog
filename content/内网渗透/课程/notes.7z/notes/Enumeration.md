Using .Net classes, no need administrator privileges
```
$ADClass = [System.DirectoryServices.ActiveDirectory.Domain]
$ADClass::GetCurrentDomain()
```

More effective and useful tools can be used:

- [PowerView](https://github.com/PowerShellMafia/PowerSploit/blob/master/Recon/PowerView.ps1) (`. .\PowerView.ps`)
- [ActiveDirectory Powershell module](https://github.com/samratashok/ADModule)(from Microsoft) (`Import-Module .\Microsoft.ActiveDirectory.Management.dll` or `Import-Module .\ActiveDirectory.psd1`)

## Basic

##### Get current domain

`Get-NetDomain`(PowerView command)

`Get-ADDomain`(ActiveDirectory Powershell module)

##### Get object of another domain(if have trust, eg, from child to parent)

`Get-NetDomain -Domain <domain_name>`

`Get-ADDomain -Identity <domain_name>`

##### Get domain SID of the current domain

`Get-DomainSID`

`(Get-ADDomain).DomainSID`

##### Get domain policy

`Get-DomainPolicy`

`(Get-DomainPolicy [-domain <domain_name>])."system access"`

`(Get-DomainPolicy [-domain <domain_name>])."Kerberos Policy"`

#####  Get domain controller

`Get-NetDomainController [-Domain <domain_name>]`

`Get-ADDomainController [-DonameName <domain_name>]`

##### Get list of users in the current domain

`Get-NetUser [-Username <username>]`

`Get-ADUser [-Filter *] [-Properties *] [-Identity *]`

##### Get list of all properties for users in the current domain

`Get-UserProperty [-Properties <property_name>]`

`Get-UserProperty -Properties logincount` (those users with few login counts might be inactive users or decoy user)

##### Search for a particular string in a user's attributes

`Find-UserField -SearchField Description -SearchTerm "build"`

`Get-AdUser -Filter 'Description -like "*build*" -Properties Description | select name, Description'`

##### Get a list of computers in the current domain(does not necessarily to be an actual computer)

`Get-NetComputer`, `Get-NetComputer -OperatingSystem "*Server 2016"`, `Get-NetComputer -Ping`, `Get-NetComputer -FullData`

`Get-ADComputer -Filter * | select Name`, `Get-ADComputer -Filter 'OperatingSystem -like "*Server 2016" -Properties OperatingSystem | select Name, OperatingSystem'`, `Get-ADComputer -Filter * - Properties DNSHostName | %{Test-Connection -Count 1 -ComputerName $_.DNSHostName}`, `Get-ADComputer -Filter * -Properties *`

##### Get all the groups in the current domain

`Get-NetGroup`, `Get-NetGroup -Domain domain_name`, `Get-NetGroup -FullData`

`Get-ADGroup`, `Get-ADGroup -Filter * | select Name`, `Get-ADGroup -Filter * -Properties *`

##### Get all groups containing the word "admin" in group name

`Get-NetGroup *admin* [-Domain <domain_name>]`

`Get-ADGroup -Filter 'Name -like "*admin"' | select Name`

##### Get list of Group Policy Object(GPO) in current domain

`Get-NetGPO`, `Get-NetGPO -ComputerName <computer_name>`

`Get-GPO -All`, `Get-GPResultantSetOfPolicy -ReportType Html -Path C:\repot.html`(Provides RSoP)

##### Get GPO(s) which use Restricted Groups or groups.xml for interesting users

`Get-NetGPOGroup`

##### Get users which are in a local group of a machine using GPO

`Find-GPOComputerAdmin -ComputerName <computer_name>`

##### Get machines where the given user is member of a specific group

`Find-GPOLocation -UserName <username> -Verbose`

##### Get OUs in a domain

`Get-NetOU -FillData`

`Get-ADOrganizationalUnit -Filter * -Properties *`

##### Get GPO applied on an OU, Read GPOname from gplink attribute from Get-NetOU

`Get-NetGPO -GPOname "<gponame>"`

`Get-GPO -Guid <guid>`

## ACL(Access Control List)

enable control on the ability of a process when accessing objects in AD based on

- Access Token(identity and privileges of user)
- Security Descriptor(SID of the owner, Discretionary ACL(DACL) and System ACL(SACL))

ACL is a list of Access Control Entries(ACE), corresponds to individual permission or audit access. who has permission and what can be done.

Two types:

- DACL - permission trustees(a user or group) have on an object
- SACL - Logs success and failure audit message when an object is accessed

##### Get the ACLs associated with the specified object

`Get-ObjectAcl -SamAccountName <account_name> -ResolveGUIDs`

##### Get ACLs associated with the specified prefix to be used for search

`Get-ObjectAcl -ADSprefix 'CN=Adminsitrator, CN=Users' -Verbose`

##### Enumerate ACLs using ActiveDirectory module but without resolving GUIDs

`(Get-Acl 'AD:\CN=Administrator,CN=Users,DC=<dc_name>,DC=local').Access`

##### Get the ACLs associated with the specified LDAP path to be used for search

`Get-ObjectAcl -ADSpath "LDAP://CN=Domain Admins,CN=users,DC=<domain_name>,DC=local" -ResolveGUIDs -Verbose`

##### Search for interesting ACEs(useful)

`Invoke-ACLScanner -ResolveGUIDs`

##### Get the ACLs associated with the specified path

`Get-PathAcl -Path "\\<dc_name>\sysvol"`

## Trust

relationship between two domains or forests which allows users from one domain or forest to visit the resources of the others

- automatic: parent-child, same forest
- established: forest, external

Trusted Domain Objects(TDOs) represent the trust relationship in a domain

##### Direction

- one-way trust: Direction of Access is opposite to the Direction of Trust

- two-two trust: users of both domains can access resources in the other domain

##### Transitivity

extended to established trust relationships with other domain

##### Nontransitivity

- can be two-way or one-way

- default trust(external trust) between two domains in different forests when forest don't have trust relationship

##### Default/Automatic Trust

Parent-child trust: 

- created automatically whenever a new domain is added in a tree. child.corporate.local is a child of corporate.local

- always two-way transitive

Tree-root trust

- created automatically between whenever a new domain tree is added to a forest root.
- always two-way transitive

Shortcut trust

- used to reduce access times in complex trust scenarios
- can be one-way or two-way transitive

External trust

- between two domains in different forests when forests do not have a trust relationship
- can be one-way or two-way, non-transitive

Forest trust

- between forest root domain
- can be one-way or two-way and transitive or non-transitive

#### Domain Trust Mapping

##### Get a list of all domain trusts for the current domain

`Get-NetDomainTrust`, `Get-NetDomainTrust -Domain <domain_name>`

`Get-ADTrust`, `Get-ADTrust -Identity <domain_name>`

Forest mapping

##### Get details about the current forest

`Get-NetForest`, `Get-NetForest -Forest <domain_name>`

`Get-ADForest`, `Get-ADForest -Identity <domain_name>`

##### Get all domains in the current forest

`Get-NetForestDomain`, `Get-NetForestDomain -Forest <domain_name>`

`(Get-ADForest).Domains`

##### Get all global catalogs for the current forest

`Get-NetForestCatalog`, `Get-NetForestCatalog -Forest <domain_name>`

`Get-ADForest | select -ExpandProperty GlobalCatalogs`

Map trusts of a forest

`Get-NetForestTrust`, `Get-NetForestTrust -Forest <domain_name>`

`Get-ADTrust -Filter 'msDS-TrustForestTrustInfo -ne "$null"'`

## User Hunting

##### Find all machines on the current domain where the current user has local admin access

`Find-LocalAdminAccess -Verbose`

a much more noisy and intrusive compared to the above commands

This function queries the DC of the current or provided domain for a list for computers(`Get-NetComputer`) and then use multi-threaded `Invoke-CheckLocalAdminAccess` on each machine.

in case the ports(RPC and SMB) used by `Find-LocalAdminAccess` are blocked, use the tool `Find-WMILocalAdminAccess.ps1` , `Find-WMILocalAdminAccess -ComputerFile .\computers.txt -Verbose`

##### Find computers where a domain admin(or any other specified user/group) has sessions on

`Invoke-UserHunter`, `Invoke-UserHunter -GroupName "RDPUsers"`

queries the DC of the current or provided domain for members of the given group(Domain Admins by default) using `Get-NetGroupMember`, gets a list of computers(`Get-NetComputer`) and list sessions and logged on users(`Get-NetSession/Get-NetLoggedon`) from each machine

to confirm admin access:

`Invoke-UserHunter -CheckAccess`

##### Find computers where a domain admin is logged-in

`Invoke-UserHunter -Stealth`

queries the DC for members of the given group(Domain Admin by default) uising `Get-NetGroupMember`, gets a list **only** of high traffic servers(DC, File Servers and Distributed File servers) for less traffic generation and list sessions and logged on users(`Get-NetSession`/`Get-NetLoggedOn`)

## BloodHound

`c:\bloodhound\Ingestors\SharpHound.ps1`

upload the generated archive  to the BloodHound application

`Invoke-BloodHound -CollectionMethod All [-ExcludeDC]`