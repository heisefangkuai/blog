- Missing Patches
  - windows exploit suggester: https://github.com/bitsadmin/wesng
  - https://github.com/SecWiki/windows-kernel-exploits
- Automated deployment and AutoLogon passwords in clear text or easily-decrypted ciphertext
- Impersonation privileges, all kinds of potatoes
  - [RottenPotato](https://github.com/foxglovesec/RottenPotato), [RottenPotatoNG](https://github.com/breenmachine/RottenPotatoNG)
  - [JuicyPotato](https://github.com/ohpe/juicy-potato)
  - [PrintSpoofer](https://github.com/itm4n/PrintSpoofer)
- AlwaysInstallElevated(allow user to run .msi file as system)
  - both `reg query HKCU\SOFTWARE\Policies\Microsoft\Windows\Installer /v AlwaysInstallElevated` and `reg query HKLM\SOFTWARE\Policies\Microsoft\Windows\Installer /v AlwaysInstallElevated`  are set to 1
- Misconfigured Services
- DLL Hijacking

### Misconfigured Services

Using [PowerUp](https://github.com/PowerShellMafia/PowerSploit/tree/master/Privesc)

- unquoted paths with space

  `Get-ServiceUnquoted -Verbose`

- current user can write its binary path or change arguments to the binary

  `Get-ModifiableServiceFile -Verbose`

- current user can modify the configuration of the services

  `Get-ModifiableService -Verbose`

- **Run all checks**

  `Invoke-AllChecks` using PowerUp

  `.\beRoot.exe` using [BeRoot](https://github.com/AlessandroZ/BeRoot)

  `Invoke-PrivEsc` using [Privesc](https://github.com/enjoiz/Privesc)

### Feature Abuse of enterprise applications

- Continuous Integration tools like Jenkins  needs system/local administrator privileges to run, and users are allow to create tasks, which will be run with the same privileges.